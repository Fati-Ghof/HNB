function P = cal_joint_prob2(vec1,c1,vec2,c2)

% vec1: vector of ith feature
% c1 : the number of values per ith feature 
% vec2: vector of jth feature
% c2 : the number of values per jth feature
m=1;
Pr=zeros(length(c1),length(c2));
for d=1:length(vec1)  
    for i=1:length(c1)
        for j=1:length(c2)
            if vec1(d)==c1(i) && vec2(d)==c2(j)
               Pr(i,j)=Pr(i,j)+1;
            end
        end
    end
end

P=(1/(length(vec1)+m))*(Pr+(2*m/(length(c1)+length(c2))));

% Eliminating the zero elements
% temp1=P==0;
% P=P+temp1.*(10^(-7));