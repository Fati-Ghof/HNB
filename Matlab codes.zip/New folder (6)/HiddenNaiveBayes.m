clc, clear all
load data.mat
num_class=8;
num_fea =8;
A1=mytest; % discretized test data
E1=mytrain; % discretized train data
Center=Cen1; % centers of quantized data


%%
for i=1:num_class
    num_train_vec(i,1)=sum(E1(:,end)==i); % a vector with size num_class*1 that its elements are the number of training data per class
end
% 
%% part 1
CostMatrix1=zeros(num_fea,num_fea);
for i=1:num_fea
    for j=1:num_fea
        if i<j % Ip is symmetric
           I(i,j) = condmutualinfo(E1(:,i),Center{1,1}{1,i},E1(:,j),Center{1,1}{1,j},E1(:,num_fea+1),Center{1,1}{1,num_fea+1},num_class);
        elseif i==j
            I(i,j)=0;
        end
    end
end

Ip=(I+I');   
%W=10^(-10)*ones(num_fea,num_fea);
vec=sum(Ip);
for i=1:num_fea
    Denominator(i)=vec(i);
    %Ip(i,i)=Ip(i,i)/2;
    W(i,:)=(Ip(i,:)/Denominator(i));
   % w1(i,:)=(W(i,:)>(min(W(i,:))));
end

% 
% 
% % % Determining labels of test data
[m,n]=size(A1);
Pr2=zeros(m,num_fea,num_fea,num_class);
Pr1=zeros(m,num_fea,num_fea,num_class);

for d=1:m

    for i=1:num_class
        AA1=sum(num_train_vec(1:i-1));
        AA2=sum(num_train_vec(1:i));
        for j=1+AA1:AA2
            for k=1:num_fea
                for l=1:num_fea
                    if k~=l
                        if E1(j,k)==A1(d,k) && E1(j,l)==A1(d,l)
                            Pr2(d,k,l,i)=Pr2(d,k,l,i)+1;
                        end
                    end
                   temp(d,k,l,i)=W(k,l);
                end
                if E1(j,k)==A1(d,k)
                   Pr1(d,k,:,i)=Pr1(d,k,:,i)+1;
                end
            end
        end
    end 
end

 for i=1:num_fea
     Pr2(:,i,:,:)=Pr2(:,i,:,:)+(1/size(Center{1,1}{1,i},2));
 end
 
 for j=1:num_fea
     Pr1(:,j,:,:)=Pr1(:,j,:,:)+1;
 end
 
 
for i=1:num_class
    f(i)=sum(E1(:,num_fea+1)==i); %the frequency of instances with class i
    Pc(i)=(f(i)+1/num_class)/(num_train_vec(i,1)+1);
end
AA=ones(m,num_class);
for k=1:m
    con_Pr(1,:,:,:)=Pr2(k,:,:,:)./Pr1(k,:,:,:);
    for s1=1:num_fea
        con_Pr(1,s1,s1,:)=0;
    end
    zzz=con_Pr.*temp(k,:,:,:);
    P=sum(zzz,3);
    for j=1:num_class
        for i=1:num_fea
             AA(k,j)=AA(k,j)*P(1,i,1,j);
        end
        C(k,j)=AA(k,j)*Pc(j);
    end
end
[val,II]=max(C,[],2);
[AUC,TRUST]=metric_per_class(num_class,A1,II) 

% % % % 
F=(2*AUC.*TRUST)./(AUC+TRUST)
