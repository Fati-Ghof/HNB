function h = condmutualinfo(vec1,c1,vec2,c2,convec,c3,num_class)
% vec1: vector of ith feature
% c1 : the number of values per ith feature 
% vec2: vector of jth feature
% c2 : the number of values per jth feature
% convec: vector of classes
% c3 : the number of classes that is class numbers


pxyz=cal_joint_prob3(vec1,c1,vec2,c2,convec,c3); % joint probability of three variable

pxz=cal_joint_prob2(vec1,c1,convec,c3); % joint probability of two variable

pyz=cal_joint_prob2(vec2,c2,convec,c3); % joint probability of two variable

for l=1:num_class
    pz(l)=sum(convec==l)/length(convec);
end

% Calculating Conditional Mutual Information based on I(X;Y|Z)=\sum_{x,y,z}P(x,y,z)log\frac{P(x,y|z)}{P(x|z)*P(y|z)}
for i=1:length(c1)
    for j=1:length(c2)
        for k=1:length(c3)
%             if pxyz(i,j,k)==0 || pxz(i,k)==0 || pyz(j,k)==0|| pz(k)==0
%                 I(i,j,k)=0;
%             else
             I(i,j,k)=pxyz(i,j,k)*log10(pz(k)*pxyz(i,j,k)/(pxz(i,k)*pyz(j,k)));
            %end
        end
    end
end

h=sum(sum(sum(I)));
